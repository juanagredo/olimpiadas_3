class carroRojo {
    constructor(x,y,ancho,alto,velocidad){
        this.x = x;
        this.y = y;
        this.ancho = 105;
        this.largo = 60;
        this.velocidad = (Math.random()*(3-1)+2);
    }
pintar(){
    noStroke();
    fill(247, 6, 6);
    rectMode(CENTER);
    rect(this.x,this.y,this.ancho,this.largo);
    fill(235);
    rect(this.x,this.y,this.ancho/2,this.largo);
    fill(195,105,255);
    rect(this.x,this.y,this.ancho/2,this.largo/1.2);
    fill(255);
    rect(this.x,this.y,this.ancho/3,this.largo);
    fill(255,255,0);
    rect(this.x - this.ancho/2,this.y + this.largo/3,this.largo/10,this.ancho/10);
    rect(this.x - this.ancho/2,this.y - this.largo/3,this.largo/10,this.ancho/10);
    
}
mover(){
    this.x -= this.velocidad;
		
    if (this.x<0) {
        this.x=810;
    }	
}
getX(){
    return this.x;
}
getY(){
    return this.y;
}

}