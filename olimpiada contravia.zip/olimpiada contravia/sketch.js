let fondo;
let imagenPerder;
let imagenGanar;
let imagenRestart;

let y;
let x;

let listaCR;
let perdiste;
let restart;

let cuenta;


let ganaste;


function preload() {

  fondo = loadImage('Assets/Group 3.png');
  imagenPerder = loadImage('Assets/Group 1.png');
  imagenRestart = loadImage('Assets/Group 4.png');
  imagenGanar = loadImage('Assets/Group 5.png');

}


function setupRestart() {

  ganaste = false;

  lineas = 12;


  x = 80;
  y = 320;
  listaCR = [];
  perdiste = false;
  restart = false;
  contador = 0;

  posX = 250;
  posY = 80;




  for (i = 0; i < 4; i++) {


    posX += 200;

    if (posX > 500) {
      posX = (random(350, 840));
      posY += 120;
    }

    if (posY > 500) {
      posX = -50;
    }
    listaCR[i] = new carroRojo(posX, posY)
  }

}

function setup() {
  createCanvas(800, 525);



  setupRestart();


}

function draw() {

  // background(255);
  image(fondo, 0, 0);
  posX = 10;
  posY = 20;





  for (i = 0; i < listaCR.length; i++) {

    listaCR[i].pintar();
    if (perdiste === false && ganaste === false) {
      listaCR[i].mover();
    }

    if (dist(x, y, listaCR[i].getX(), listaCR[i].getY()) < 100) {
      perdiste = true;
    }
  }

  Carro1();
  if (perdiste === false) {
    x += 4;
    if (x > 800) {
      ganaste = true;
    }
  }

  if (perdiste === true) {
    image(imagenPerder, 290, 220);
    contador++;
    if (contador > 150) {
      restart = true;
    }

  }

  if (ganaste === true) {



    image(imagenGanar, 290, 220);
    image(imagenRestart, 290, 300);
    contador++;
    if (mouseIsPressed || keyIsPressed) {
      restart = true;
    }

  }

  if (restart == true) {
    setupRestart();
  }

  if (y > 500) {
    y = 440
  }
  if (y < 0) {
    y = 80
  }

}

function Carro1() {
  x = x;
  y = y;
  ancho = 100;
  largo = 50;

  noStroke();

  fill(0);
  rectMode(CENTER);
  rect(x, y, ancho, largo);
  fill(235);
  rect(x, y, ancho / 2, largo);
  fill(105, 105, 255);
  rect(x, y, ancho / 2, largo / 1.2);
  fill(255);
  rect(x, y, ancho / 3, largo);
  fill(255, 255, 0);
  rect(x + ancho / 2, y + largo / 3, largo / 10, ancho / 10);
  rect(x + ancho / 2, y - largo / 3, largo / 10, ancho / 10);
}

function keyPressed() {
  if (key == 'w') {
    y -= 120;
  }

  if (key == 's') {
    y += 120;
  }
  if (key == 'W') {
    y -= 120;
  }

  if (key == 'S') {
    y += 120;
  }
}