class Block {
    constructor(location, width, height) {
        this.location = location;
        this.width = width;
        this.points = 1;
        this.height = height;
        this.colorsr = int(random(100, 205));
        this.colorsg = int(random(0, 255));
        this.colorsb = int(random(230, 255));



    }
    display() {
        noStroke();
        fill(this.colorsr, this.colorsg, this.colorsb);
        rect(this.location.x, this.location.y, this.width, this.height);

    }

    colliding(ball) {
        // collide with brick

        if (ball.location.y - ball.radius <= this.location.y + this.height &&
            ball.location.y + ball.radius >= this.location.y &&
            ball.location.x + ball.radius >= this.location.x &&
            ball.location.x - ball.radius <= this.location.x + this.width) {
            return true;
        }

    }





}