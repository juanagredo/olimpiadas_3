function setup() {
  createCanvas(750, 700);

  paddle = new StickBounce();
  ball = new Ball(paddle);
  playing = true;
  bricks = []
  bricks = createBricks()
}
let ball;
let bricks = [];
let paddle;
let playing;
let playerScore = 0;

function createBricks() {
  const bricks = []
  const brickwidth = 100
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 6; j++) {
      brick = new Block(createVector(50 + ((brickwidth + 10) * j), 20 + (i * (25 + 10))), brickwidth, 25)
      bricks.push(brick)
    }
  }
  return bricks
}





function draw() {
  background(239, 239, 240);
  ball.bounceEdge();
  ball.update();
  ball.bouncePaddle();
  if (ball.belowBottom() && bricks.length != 0) {
    textSize(70);
    playing = false
    fill(3, 6, 20);
    text(`Y0U LOOSE XP`, width / 2 - 250, height / 2 + 60);
  }




  if (keyIsDown(LEFT_ARROW)) {
    paddle.move('left');

  } else if (keyIsDown(RIGHT_ARROW)) {
    paddle.move('right');
  }

  paddle.display();
  ball.display();


  if (bricks.length === 0) {
    textSize(90);
    playing = false
    fill(0, 12, 10);
    text(`Y0U W0N :D`, width / 2 - 250, height / 2);
  }

  for (let i = bricks.length - 1; i >= 0; i--) {

    const brick = bricks[i]
    brick.display();
    if (brick.colliding(ball)) {
      ball.reverse('y');
      bricks.splice(i, 1)
      playerScore += brick.points
    }
  }


  textSize(22);
  fill(0);
  text(`Score: ` + playerScore, 50, 660);

}