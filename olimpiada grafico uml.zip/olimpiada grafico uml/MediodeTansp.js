class MediodeTransp {

    constructor(x, y, tam, r, g, b, ) {
  
  
      if (new.target === MediodeTransp) {
  
  
  
        window.stop()
  
  
        throw new error("Ahora si este es un error serio >:|");
  
      };
  
  
      this.x = x;
      this.y = y;
      this.tam = tam;
    
      this.r = r;
      this.g = g;
      this.b = b;
    }
  
  
    mostrar() {
      noStroke();
      fill(this.r, this.g, this.b);
     
    }
  
   
  
  }
  