
class Cocheperodepolicia extends Coche {

    constructor(x, y, tam, r, g, b,  ruedaTam) {
      super(x, y, tam, r, g, b, ruedaTam)
  
  
      this.colorsirena = true;
  
  
      this.r = 0;
      this.g = 0;
      this.b = 0;
  
  
  
    }
  
    mostrar() {
  
      super.mostrar();
  
  
  
      fill(255);
      rect(this.x + this.tam / 6, this.y - (this.tam / 4), this.tam - ((this.tam / 6) * 2), this.tam - (this.tam / 10) * 7);
  
      text('Police', this.x + this.tam / 6, this.y + (this.tam / 4));
  
  
      if (this.colorsirena === true) {
        fill(255, 0, 0);
      } else {
        fill(0, 0, 255);
      }
  
      rect(this.x + ((this.tam / 8) * 3)
  
        , this.y - (this.tam / 2.1)
  
        , this.tam - (this.tam / 1.3),
  
        this.tam - (this.tam / 1.3)
  
      );
  
      if (frameCount % 30 === 0) {
        this.colorsirena = !this.colorsirena
      }
  
    }
  
  }