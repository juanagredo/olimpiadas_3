  let coche;
let cochepol;
function setup() {
  createCanvas(400, 400);

  coche = new Coche(200, 200, 100, 255, 156, 197,  30);
  
  cochepol = new Cocheperodepolicia(50, 200, 100, 255, 156, 197, 30);

  console.log(coche);
}




function draw() {
  background(220);

  coche.mostrar();
  cochepol.mostrar();



}






