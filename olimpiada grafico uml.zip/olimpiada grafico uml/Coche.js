
class Coche extends MediodeTransp {

    constructor(x, y, tam, r, g, b,  ruedaTam) {
  
      super(x, y, tam, r, g, b, )
  
      this.ruedaTam = ruedaTam;
  
  
    }
  
    mostrar() {
      super.mostrar();
  
  
  
      //coche 
  
      rect(this.x, this.y, this.tam, this.tam / 2.5);
      rect(this.x + this.tam / 6, this.y - (this.tam / 4), this.tam - ((this.tam / 6) * 2), this.tam - (this.tam / 10) * 7);
  
  
      //ruedas 
      fill(40);
      circle(this.x + (this.tam / 6), this.y + (this.tam / 2), this.ruedaTam);
      circle(this.x + ((this.tam / 6) * 5), this.y + (this.tam / 2), this.ruedaTam);
      fill(250);
      circle(this.x + (this.tam / 6), this.y + (this.tam / 2), this.ruedaTam / 3);
      circle(this.x + ((this.tam / 6) * 5), this.y + (this.tam / 2), this.ruedaTam / 3);
  
    }
  
  }