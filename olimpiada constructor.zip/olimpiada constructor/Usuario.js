class Usuario {

	constructor(x, genero, fondo, piel, camisa, cabello) {

		this.fondo = fondo;
		this.piel = piel;
		this.camisa = camisa;
		this.cabello = cabello;


		this.x = x;
		this.y = 300;


		this.genero = genero;


		this.tamaño = 150;
	}

	pintar() {


		noStroke();
		this.Pintarfondo();


		if (this.genero === true) {
			switch (this.cabello) {

				case 0:
					fill(255, 223, 89);
					break;

				case 1:
					fill(0, 37, 91);
					break;

				case 2:
					fill(196, 137, 93);
					break;
			}

			rect(this.x, this.y - this.tamaño / 17, this.tamaño / 1.8, this.tamaño / 1.4);
		}
		this.Pintarcamisa();

		fill(200, 55, 100);
		rectMode(CENTER);
		rect(this.x, this.y - 10, this.tamaño / 5);

		this.Pintarcabeza();
		this.Pintarcabello();

	}



	Pintarfondo() {
		switch (this.fondo) {
			case 0:
				fill(158, 149, 233);
				break;

			case 1:
				fill(149, 212, 233);
				break;

			case 2:
				fill(255, 249, 136);
				break;

			case 3:
				fill(255, 173, 173);
				break;

		}
		circle(this.x, this.y, this.tamaño - this.tamaño / 10);
	}



	Pintarcabeza() {

		switch (this.piel) {
			case 0:
				fill(254, 243, 206);
				break;

			case 1:
				fill(226, 196, 172);
				break;

			case 2:
				fill(177, 120, 83);
				break;

		}

		ellipse(this.x, this.y - this.tamaño / 3, this.tamaño / 2, this.tamaño / 1.5);

		fill(0);
		ellipse(this.x - 20, this.y - this.tamaño / 3.5, this.tamaño / 17, this.tamaño / 12);
		ellipse(this.x + 20, this.y - this.tamaño / 3.5, this.tamaño / 17, this.tamaño / 12);
		fill(255);
		arc(this.x, this.y - this.tamaño / 5, this.tamaño / 5, this.tamaño / 6, 0, PI);
	}





	Pintarcamisa() {
		switch (this.camisa) {
			case 0:
				fill(154, 70, 196);
				break;
			case 1:
				fill(15, 204, 211);
				break;
			case 2:
				fill(246, 225, 23);
				break;

			case 3:
				fill(230, 33, 33);
				break;
		}

		arc(this.x, this.y, this.tamaño, this.tamaño, PI / 3 - ((PI / 180) * 40), 2 * PI / 3 + ((PI / 180) * 40));
		fill(255);
		triangle(this.x - this.tamaño / 5, this.y, this.x, this.y + this.tamaño / 3, this.x + this.tamaño / 5, this.y);
		fill(18, 3, 26);
		triangle(this.x - this.tamaño / 10, 305, this.x, 350, this.x + this.tamaño / 10, 305);
	}




	Pintarcabello() {
		switch (this.cabello) {

			case 0:
				fill(255, 235, 89);
				break;

			case 1:
				fill(0, 32, 140);
				break;

			case 2:
				fill(205, 160, 99);
				break;


		}
		if (this.genero === false) {
			noStroke();
			

			quad(this.x - this.tamaño / 10, this.y - this.tamaño / 1.4, this.x - this.tamaño / 3.8,
				this.y - this.tamaño / 1.7, this.x - this.tamaño / 3, this.y - this.tamaño / 3, this.x, this.y - this.tamaño / 1.6);

			quad(this.x + this.tamaño / 10, this.y - this.tamaño / 1.4, this.x + this.tamaño / 3.8,
				this.y - this.tamaño / 1.7, this.x + this.tamaño / 3, this.y - this.tamaño / 3, this.x, this.y - this.tamaño / 1.6)

			ellipse(this.x, this.y - this.tamaño / 1.5, this.tamaño / 5, this.tamaño / 10);

			

		}

		noStroke();


		if (this.genero === true) {
			quad(this.x - this.tamaño / 20, this.y - this.tamaño / 1.3, this.x - this.tamaño / 3.8,
				this.y - this.tamaño / 1.7, this.x - this.tamaño / 3, this.y - this.tamaño / 3, this.x + this.tamaño / 20, this.y - this.tamaño / 1.6);

			quad(this.x + this.tamaño / 20, this.y - this.tamaño / 1.3, this.x + this.tamaño / 3.8,
				this.y - this.tamaño / 1.7, this.x + this.tamaño / 3, this.y - this.tamaño / 3, this.x - this.tamaño / 20, this.y - this.tamaño / 1.6)
		}
	}


}