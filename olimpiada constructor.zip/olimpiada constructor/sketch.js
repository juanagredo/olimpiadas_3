let usuario1, usuario2, usuario3,usuario4;

function setup() {
  createCanvas(700, 600); 

  /*
  fondo y camisa
  0 =morado.
  1 =celeste.
  2 =amarillo.
  3 =rojo.

  piel
  0 =clara
  1 =media
  2 =oscura

  cabello 
  0 =rubio 
  1 =oscuro
  2 =castaño
  
   usuario# = new Usuario(posicion x,genero,color fondo ,color piel 0,color camisa 3,color cabello 0);
  */

  usuario1 = new Usuario(110,false ,0 , 0, 3, 0);
  usuario2 = new Usuario(270,true  ,1 , 1, 0, 1);
  usuario3 = new Usuario(430,false ,2 , 2, 2, 2);
  usuario4 = new Usuario(590,true  ,3 , 0, 1, 0);
}

function draw() {
  background(250);

  usuario1.pintar();
	usuario2.pintar();
	usuario3.pintar();
	usuario4.pintar();
}