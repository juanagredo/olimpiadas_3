
class SpicyInvader {

    constructor(x, y) {
      this.x = x;
      this.y = y;
      this.size = 34;
  
  
  
    }
  
    display() {
  
      strokeWeight(2);
      stroke(5)
  
      fill(145, 21, 211);
  
      rect(this.x + this.size / 12, this.y - this.size / 3, this.size / 4, this.size - this.size / 4)
      rect(this.x + this.size - this.size / 3, this.y - this.size / 3, this.size / 4, this.size - this.size / 4)
  
      square(this.x, this.y, this.size)
  
      rect(this.x - this.size / 4, this.y + this.size / 4, this.size / 4, this.size / 2)
      rect(this.x + this.size, this.y + this.size / 4, this.size / 4, this.size / 2)
  
      rect(this.x - this.size / 2, this.y + this.size / 2, this.size / 4, this.size - this.size / 2)
      rect(this.x + this.size + this.size / 4, this.y + this.size / 2, this.size / 4, this.size - this.size / 2)
  
      rect(this.x, this.y + this.size, this.size / 4, this.size / 4)
      rect(this.x + this.size - this.size / 4, this.y + this.size, this.size / 4, this.size / 4)
  
      noStroke();
      fill(237);
  
      square(this.x + this.size / 8, this.y + this.size / 4, this.size / 5);
  
      square(this.x - this.size / 5 - this.size / 8 + this.size, this.y + this.size / 4, this.size / 5);
  
      if (frameCount % 30 === 0) {
        this.y += 5;
      }
  
    }
  
  
    GetInvaderY() {
      return this.y;
    }
  
  
  
  }