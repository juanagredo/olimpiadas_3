let invader;
let invader2;

let Xshooter;
let Ybullet;
let Xbullet;

let left;
let right;

let charged;
let shoot;

let line1 = [];
let line2 = [];

let verify1 = [];
let verify2 = [];

let score;
let win = false;
let lose = false;

function setup() {
  createCanvas(600, 600);

  for (let i = 0; i < 4; i++) {

    line1[i] = new SpicyInvader(60 + (i * 150), 100);
    verify1[i] = 1;

  }

  for (let i = 0; i < 3; i++) {

    line2[i] = new SpicyInvader(135 + (i * 150), 190);
    verify2[i] = 1;
  }

  score = 0;

  Xshooter = 200;

  Ybullet = 520;
  Xbullet = Xshooter + 28;

  charged = true;

  left = false;
  right = false;

  shoot = false;
}


for (let i = 0; i < 4; i++) {
  if (verify1[i] === 0) {
    score = score + 1
  }

}

function draw() {
  background(20, 17, 64);

  line(0, 500, 600, 500);

  if (lose === false && win === false) {



    for (let i = 0; i < 4; i++) {
      if (verify1[i] != 0) {
        line1[i].display();

        if (line1[i].GetInvaderY() + 46 > 500) {
          rect(0, 0, 600);
          lose = true;
        }

        if (Xbullet > 30 + (i * 150) && Xbullet < 110 + (i * 150) && Ybullet > line1[i].GetInvaderY() && Ybullet < line1[i].GetInvaderY() + 46) {

          score++;
          text("explosion", 60 + (i * 150), line1[i].GetInvaderY() + 20);
          verify1[i] = 0;

        }

      }

    }

    for (let i = 0; i < 3; i++) {
      if (verify2[i] != 0) {
        line2[i].display();

        if (line2[i].GetInvaderY() + 46 > 500) {
          lose = true;
          rect(0, 0, 600);

        }


        if (Xbullet > 100 + (i * 150) && Xbullet < 190 + (i * 150) && Ybullet > line2[i].GetInvaderY() && Ybullet < line2[i].GetInvaderY() + 46) {
          score++;
          text("explosion", 130 + (i * 150), line2[i].GetInvaderY() + 20);


          verify2[i] = 0;


        }
      }
    }

    shooter();
  }

  if (score === 7) {
    win = true;
  }

  if (lose) {
    noStroke();
    textSize(20);
    text("You lose :( press F5 to reload X|", 130, 290);

  }
  if (win) {
    noStroke();
    textSize(20);
    text("You Won!!! press F5 to reload XD", 130, 290);

  }
}

function shooter() {

  fill(255, 243, 64);

  rect(Xshooter, 550, 70, 25, 4);
  fill(255);
  rect(Xshooter + 15, 535, 40, 15, 5, 5, 0);

  strokeWeight(6);
  stroke(255, 153, 0, 45);
  fill(255, 217, 0);

  if (charged) {

    shoot = false;

    Xbullet = Xshooter + 28;
    Ybullet = 520;
    rect(Xbullet, Ybullet, 14, 25, 100, 100, 3);

  }

  if (right) {
    Xshooter += 3
  }
  if (left) {
    Xshooter -= 3
  }

  if (shoot) {

    rect(Xbullet, Ybullet, 14, 25, 100, 100, 3);
    Ybullet -= 4;

    if (Ybullet < -25) {
      charged = true
    }

  }

}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {


    left = true;
  }

  if (keyCode === RIGHT_ARROW) {

    right = true;
  }

  if (keyCode === UP_ARROW) {

    shoot = true;

    charged = false;

  }
}


function keyReleased() {
  if (keyCode === LEFT_ARROW) {


    left = false;
  }
  if (keyCode === RIGHT_ARROW) {

    right = false;
  }
}