class PaloRebote {

    constructor(posX, posY, tipopalo) {
  
      this.tP = tipopalo
      this.x = posX;
      this.y = posY;
      this.ancho = 20;
      this.largo = 100;
  
      this.r = random(100, 255);
      this.b = random(100, 255);
  
      this.dirbolaX = false;
      this.dirbolaX = false;
  
    }
  
  
    mostrar() {
  
      noStroke();
      fill(this.r, 130, this.b);
  
      rect(this.x, this.y, this.ancho, this.largo);
  
      this.mover();
  
    }
  
  
    mover() {
      if (mouseIsPressed === true) {
        if (this.tP === 2 && mouseX < 501 && mouseX > 420 && mouseY > this.y - 13 && mouseY < this.y + 113) {
          this.y = mouseY - 50;
        }
      }
  
      if (this.tP === 1) {
        if (keyIsPressed) {
  
          if (key === 'w' || key === 'W') {
            this.y -= 4
          }
          if (key === 's' || key === 'S') {
            this.y += 4
          }
  
        }
      }
  
      if (this.y > 399) {
        this.y = 399
      }
      if (this.y < 0) {
        this.y = 0
      }
  
    }
  
  
  
    getposY() {
      return this.y;
    }
  
  }