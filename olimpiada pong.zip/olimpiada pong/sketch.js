let palop1;
let palop2;
let bola;

let img;
let img2;

function preload() {
  img = loadImage('/Assets/Group 1.png');
  img2 = loadImage('/Assets/Group 2.png');
}

function setup() {
  createCanvas(500, 500);

  palop1 = new PaloRebote(20, 225, 1);
  palop2 = new PaloRebote(460, 225, 2);
  bola = new Bola(250, 250);


}
let moverya = 0;

function draw() {



  background(240, 246, 220);

  palop1.mostrar();
  palop2.mostrar();

  bola.mostrar(moverya);

  bola.setPalop1(palop1.getposY());
  bola.setPalop2(palop2.getposY());

  if (mouseIsPressed || keyIsPressed) {
    moverya = 1
  };


}





