class Bola {

    constructor(x, y) {
  
      this.bolX = x;
      this.bolY = y;
  
      this.dirX = random(int(0, 1));
      this.dirY = random(int(0, 1));
  
      this.vel = 2;
  
      this.puntosDer = 0;
      this.puntosIzq = 0;
  
  
    }
  
    mostrar(mov) {
  
      fill(200, 32, 62);
      circle(this.bolX, this.bolY, 26);
      this.mover(mov);
    }
  
  
  
  
  
    mover(mov) {
  
      this.movimiento = mov;
  
  
  
      if (this.bolY <= 12) {
        this.dirY = 1;
      }
      if (this.bolY >= 488) {
        this.dirY = 0;
      }
  
      if (this.bolX <= -10) {
        this.puntosIzq += 1;
        this.dirX = 1;
        this.movimiento = 3;
      }
      if (this.bolX >= 510) {
        this.puntosDer = 1;
        this.dirX = 0;
        this.movimiento = 3;
      }
  
      switch (this.movimiento) {
        case 0:
          this.bolX = 250;
          this.bolY = 250;
  
          image(img, 420, 240);
          image(img2, 60, 235);
  
  
  
  
          break;
  
        case 1:
  
          switch (this.dirY) {
            case 0:
              this.bolY = this.bolY - this.vel;
  
              break;
  
            case 1:
              this.bolY = this.bolY + this.vel;
  
  
              break;
          }
  
          switch (this.dirX) {
            case 0:
              this.bolX = this.bolX - 2;
  
              break;
  
            case 1:
              this.bolX = this.bolX + 2;
  
  
              break;
          }
          break;
        case 3:
          this.bolX = 250;
          this.bolY = 250;
  
  
  
  
          break;
      }
  
  
  
      this.rebote();
  
  
      fill(40);
      textSize(23);
      text(this.puntosIzq + " - " + this.puntosDer, 220, 20);
  
    }
    setPalop1(pospalo1) {
      this.pospalo1Y = pospalo1
    }
    setPalop2(pospalo2) {
      this.pospalo2Y = pospalo2
    }
  
  
    rebote() {
      //palo izq
      if (this.bolY > this.pospalo1Y && this.bolY < this.pospalo1Y + 30 && this.bolX > 20 + 13 && this.bolX < 30 + 13) {
  
        this.dirX = 1;
        this.vel = 3;
  
      }
  
      if (this.bolY > this.pospalo1Y + 29 && this.bolY < this.pospalo1Y + 71 && this.bolX > 20 + 13 && this.bolX < 30 + 13) {
  
        this.dirX = 1;
        this.vel = 1;
  
      }
  
      if (this.bolY > this.pospalo1Y + 70 && this.bolY < this.pospalo1Y + 101 && this.bolX > 20 + 13 && this.bolX < 30 + 13) {
  
        this.dirX = 1;
        this.vel = 3;
  
      }
  
      //palo der
      if (this.bolY > this.pospalo2Y && this.bolY < this.pospalo2Y + 30 && this.bolX > 460 - 13 && this.bolX < 480 - 13) {
  
        this.dirX = 0;
        this.vel = 3;
  
      }
  
      if (this.bolY > this.pospalo2Y + 29 && this.bolY < this.pospalo2Y + 71 && this.bolX > 460 - 13 && this.bolX < 480 - 13) {
  
        this.dirX = 0;
        this.vel = 1;
  
      }
  
      if (this.bolY > this.pospalo2Y + 70 && this.bolY < this.pospalo2Y + 101 && this.bolX > 460 - 13 && this.bolX < 480 - 13) {
  
        this.dirX = 0;
        this.vel = 3;
  
      }
      if (this.pospalo2Y) {
  
      }
  
    }
  
  
  
  }