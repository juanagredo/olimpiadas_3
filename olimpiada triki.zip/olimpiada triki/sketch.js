let tablero = [];
let turno;
let gana;

let contadorX;
let contadorO;
let contadorEmpate;

let figuraX = [];
let figuraO = [];

function setupRestart() {
  
  gana = 0;

  

  for (let i = 0; i < 3; i++) {
    tablero.push(new Array(3));
    figuraX.push(new Array(3));
    figuraO.push(new Array(3));

  }

  for (let fil = 0; fil < 3; fil++) {
    for (let col = 0; col < 3; col++) {

      tablero[fil][col] = 0;
      figuraO[fil][col] = false;
      figuraX[fil][col] = false;

    }

  }
    contadorEmpate = 0;
}

function setup() {
  createCanvas(600, 600);

  setupRestart();
  contadorX = 0;
  contadorO = 0;
  
  turno = true;
  
}

function draw() {
  background(220);

   strokeWeight(3);

      
  for (let fil = 0; fil < 3; fil++) {
    for (let col = 0; col < 3; col++) {

        
      if (gana===0) {

      square(-1 + (col * 201), -1 + (fil * 201), 201)


      if (figuraX[fil][col] === true) {

        square(25 + (col * 200), 25 + (fil * 200), 150)

      }

      if (figuraO[fil][col] === true) {

        circle(100 + (col * 200), 100 + (fil * 200), 150)

      }

      }

      if (gana === 1) {
  
  
  contadorO ++;
  setupRestart();
 
} 
if (gana === 2) {
  
  
  contadorX ++;
  setupRestart();


}

    }
  }


 if (frameCount % 80 === 0) {
    console.log(contadorO);
    console.log(contadorX);
    console.log(contadorEmpate);
} 
Victoria0Empate();


if (gana === 5) {
  
  textSize(30);
  textAlign(CENTER);
  text('X ganó',width/2,height/2);
  text('presiona una tecla para reiniciar',width/2,height/2 + 50);
  if (keyIsPressed) {

    contadorX = 0;
    contadorO = 0;

    setupRestart();
  }
  
}

if (gana === 6) {

  textSize(30);
  textAlign(CENTER);
  text('O ganó',width/2,height/2);
  text('presiona una tecla para reiniciar',width/2,height/2 + 50);
  if (keyIsPressed) {

    contadorX = 0;
    contadorO = 0;

    setupRestart();
  }
  
}

}




function Victoria0Empate() {

  if (contadorEmpate === 9) { setupRestart();
    
  }
  for (let fil = 0; fil < 3; fil++) {
    for (let col = 0; col < 3; col++) {

        
      if (gana===0) {

     
      

      // condicion de victoria

      // O

      if (figuraO[0][col] === true && figuraO[1][col] === true && figuraO[2][col] === true) {

        gana = 1;

      }

      if (figuraO[fil][0] === true && figuraO[fil][1] === true && figuraO[fil][2] === true) {

        gana = 1;

      }

      if (figuraO[0][0] === true && figuraO[1][1] === true && figuraO[2][2] === true) {

        gana = 1;

      }
      
      if (figuraO[0][2] === true && figuraO[1][1] === true && figuraO[2][0] === true) {

        gana = 1;

      }

      // X = cuadro

      if (figuraX[0][col] === true && figuraX[1][col] === true && figuraX[2][col] === true) {

        gana = 2;

      }

      if (figuraX[fil][0] === true && figuraX[fil][1] === true && figuraX[fil][2] === true) {

        gana = 2;

      }

      if (figuraX[0][0] === true && figuraX[1][1] === true && figuraX[2][2] === true) {

        gana = 2;

      }
      
      if (figuraX[0][2] === true && figuraX[1][1] === true && figuraX[2][0] === true) {

        gana = 2;

      }
      }

      

}

    }


    if (contadorX === 5) {
      gana = 5;
          }
          
    if (contadorO === 5) {
      gana = 6;
          }

  }
        
      
 
  


function mouseClicked()

{


  for (let fil = 0; fil < 3; fil++) {
    for (let col = 0; col < 3; col++) {


      if (tablero[fil][col] < 1 && turno === true) {
        
          if (dist(mouseX, mouseY, 100 + (col * 200), 100 + (fil * 200)) < 100) {
            figuraX[fil][col] = true;

            tablero[fil][col] = 1;
            turno = false;
            contadorEmpate++;

          }



        

      }


      if (tablero[fil][col] < 1 && turno === false) {
        
          if (dist(mouseX, mouseY, 100 + (col * 200), 100 + (fil * 200)) < 100) {
            figuraO[fil][col] = true;


            tablero[fil][col] = 1;
            turno = true;
            contadorEmpate++;
          
        }

      }
    }

  }


}
