function setup() {
  createCanvas(400, 400);
  fanta1 = new Fantasma(80, 80);
  fanta2 = new Fantasma(120, 80);
  fanta3 = new Fantasma(160, 80);

  pac = new Pacman(200, 200);

  frameRate(60);
}

function draw() {
  background(5, 7, 39);


  strokeWeight(4);
  fanta1.mostrar();
  fanta2.mostrar();
  fanta3.mostrar();

  pac.mostrar();

  if (dist(pac.x, pac.y, fanta1.x, fanta1.y) < 25) {
    fanta1.setcomide(true);
  }
  if (dist(pac.x, pac.y, fanta2.x, fanta2.y) < 25) {
    fanta2.setcomide(true)
  }
  if (dist(pac.x, pac.y, fanta3.x, fanta3.y) < 25) {
    fanta3.setcomide(true)
  }

}


function keyPressed()

{
  switch (key) {
    case 'w':
      pac.setdir(0);
      break;

    case 's':
      pac.setdir(1);
      break;

    case 'd':
      pac.setdir(2);
      break;

    case 'a':
      pac.setdir(3);
      break;
  }


}